package com.slippery.employeemanagement.service;

import com.slippery.employeemanagement.dto.EmployeeResponse;

public interface EmployeeService {
    EmployeeResponse getAllEmployees();
}
